package javavariable;

public class Javavariable {

    public static void main(String[] args) {
        int i=10;
 String n="Java";
 float f=5.5f;
 System.out.println("Value of i: "+i);
 System.out.println("Value of n: "+n);
 System.out.println("Value of f: "+f);
  }
    
}
