/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jaggedarray;

/**
 *
 * @author STUD
 */
public class Jaggedarray {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int [][]array=new int [2][];
       array[0]=new int[]{11,22,33,44};
       array[1]=new int[]{55,66,77};
       for(int i=0; i<array.length;i++)
       {
           for(int j=0;j<array[i].length;j++)
           {
               System.out.print(array[i][j]+"");
           }
           System.out.println();
       }
    }
    
}
