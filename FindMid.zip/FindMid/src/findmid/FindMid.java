/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package findmid;
public class FindMid {
    public static void main(int arr[]) {
        int min=arr[0];
 for(int i=1;i<arr.length;i++)
 if(min>arr[i]) min=arr[i];
 System.out.println(min);
 }
 public static void main(String args[]){
 int a[]={33,3,1,5};
 main(a);
    }
    
}
