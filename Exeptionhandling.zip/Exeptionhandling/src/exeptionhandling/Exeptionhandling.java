package exeptionhandling;

public class Exeptionhandling {

    public static void main(String[] args) {
       int a=10,b=0,c=0;
 System.out.println("Start of main()");
 try{
 c=a/b;
 }catch(ArithmeticException ae) {
 System.out.println(ae);
 }finally {
 System.out.println("I am always there...");
 }
 System.out.println("Value of C:"+c);
 System.out.println("End of main()");
 

    }
    
}
