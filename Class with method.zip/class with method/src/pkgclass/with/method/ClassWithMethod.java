/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgclass.with.method;

/**
 *
 * @author STUD
 */
public class ClassWithMethod {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       class Employee{
 int id;
 String name;
 float salary;
 void setData(int i, String n, float s) {
 id=i;
 name=n;
 salary=s;
 }
 void getData() {
 System.out.println(id+" "+name+" "+salary);
 }
}
public class TestEmployee {
 public static void main(String[] args) {
 Employee e1=new Employee();
 Employee e2=new Employee();
 e1.setData(101,"Ravi",45000);
 e2.setData(102,"Mohit",25000);
 e1.getData();
 e2.getData();
 }
} 

    }
    
}
