/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testinheritance;
class Animal{
 void eat(){
 System.out.println("eating....");
 }
}
class Dog extends Animal{
 void bark(){
 System.out.println("barking...");
 }
}
class BabyDog extends Dog{
 void weep(){
 System.out.println("weeping...");
 }
}
public class TestInheritance {

    public static void main(String[] args) {
      BabyDog d=new BabyDog();
 d.weep();
 d.bark();
 d.eat(); 
  
   }
    
}
